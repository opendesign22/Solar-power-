
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Users, Building, MapPin, Mail, Briefcase, Link2 } from 'lucide-react';

const InstallerWelcome = () => {
  return (
    <div className="container px-4 py-12 mx-auto max-w-6xl">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Join Our Network of Solar Installers</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          Connect with customers actively looking for solar installation services and grow your business with Sunalyzer
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link to="/installers/register">
            <Button size="lg" className="px-8">Register Now</Button>
          </Link>
          <Link to="/service-plans">
            <Button variant="outline" size="lg">Learn More</Button>
          </Link>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        {[
          {
            title: "Qualified Leads",
            description: "Connect with homeowners who have already calculated their solar needs and are ready to install",
            icon: Users
          },
          {
            title: "Enhanced Visibility",
            description: "Get featured in our installer directory and increase your online presence",
            icon: Building
          },
          {
            title: "Local Targeting",
            description: "Receive leads specifically from your service area to maximize conversion potential",
            icon: MapPin
          }
        ].map((benefit, index) => (
          <Card key={index} className="border shadow-sm h-full">
            <CardHeader>
              <div className="p-2 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                <benefit.icon className="h-6 w-6 text-primary" />
              </div>
              <CardTitle>{benefit.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{benefit.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* How It Works */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-10">How It Works</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              step: "1",
              title: "Register Your Business",
              description: "Fill out our simple registration form with your company information and credentials"
            },
            {
              step: "2",
              title: "Complete Your Profile",
              description: "Add your service offerings, certifications, and portfolio to stand out to potential customers"
            },
            {
              step: "3",
              title: "Start Receiving Leads",
              description: "Get matched with customers based on their location and project needs"
            }
          ].map((step, index) => (
            <div key={index} className="relative flex flex-col items-center text-center">
              <div className="w-14 h-14 rounded-full bg-primary flex items-center justify-center mb-5 text-white font-bold text-xl">
                {step.step}
              </div>
              <h3 className="text-xl font-medium mb-2">{step.title}</h3>
              <p className="text-muted-foreground">{step.description}</p>
              {index !== 2 && <div className="hidden md:block absolute top-7 left-[60%] w-[80%] border-t-2 border-dashed border-primary/30"></div>}
            </div>
          ))}
        </div>
      </div>

      {/* Testimonials */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-10">What Installers Say</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            {
              quote: "Since joining Sunalyzer, we've seen a 30% increase in qualified leads. The platform makes it easy to connect with customers who are ready to install solar.",
              author: "Sarah Johnson",
              company: "SunPower Solutions"
            },
            {
              quote: "The registration process was simple, and we started receiving interested customers within days. Great platform for growing our installation business.",
              author: "Michael Torres",
              company: "EcoSolar Installations"
            }
          ].map((testimonial, index) => (
            <Card key={index} className="border shadow-sm">
              <CardContent className="pt-6">
                <div className="mb-4">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <span key={star} className="text-yellow-500">★</span>
                  ))}
                </div>
                <p className="italic mb-4">"{testimonial.quote}"</p>
                <div>
                  <p className="font-medium">{testimonial.author}</p>
                  <p className="text-sm text-muted-foreground">{testimonial.company}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* FAQ */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-10">Frequently Asked Questions</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {[
            {
              question: "What does it cost to join the installer network?",
              answer: "Basic listing is free for verified solar installers. Premium listings with enhanced features are available for a monthly subscription fee."
            },
            {
              question: "How are leads distributed to installers?",
              answer: "Leads are matched based on customer location, project size, and your service area. Customers can also browse the directory and contact you directly."
            },
            {
              question: "What verification process do installers go through?",
              answer: "We verify business licenses, insurance information, and check references to ensure all installers in our network are reputable and qualified."
            },
            {
              question: "Can I see details about potential projects before accepting leads?",
              answer: "Yes, you'll receive project details including system size, location, and customer requirements before deciding to pursue a lead."
            }
          ].map((faq, index) => (
            <Card key={index} className="border shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">{faq.question}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">{faq.answer}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Installer Requirements */}
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-8">Registration Requirements</h2>
        <Card className="border shadow-sm">
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  requirement: "Valid business license",
                  icon: Briefcase
                },
                {
                  requirement: "Proof of insurance",
                  icon: CheckCircle
                },
                {
                  requirement: "Company contact information",
                  icon: Mail
                },
                {
                  requirement: "Professional website (recommended)",
                  icon: Link2
                }
              ].map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="p-2 rounded-full bg-primary/10">
                    <item.icon className="h-5 w-5 text-primary" />
                  </div>
                  <span>{item.requirement}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* CTA */}
      <div className="text-center bg-muted p-10 rounded-lg">
        <h2 className="text-3xl font-bold mb-4">Ready to Grow Your Solar Installation Business?</h2>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Join our network of professional installers and connect with customers looking for quality solar installation services.
        </p>
        <Link to="/installers/register">
          <Button size="lg" className="px-10">Register Now</Button>
        </Link>
      </div>
    </div>
  );
};

export default InstallerWelcome;
