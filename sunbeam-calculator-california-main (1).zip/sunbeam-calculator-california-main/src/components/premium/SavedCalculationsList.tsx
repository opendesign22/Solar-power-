
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Save, Trash, Calculator, Edit, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

// In a real app, this would come from the backend
const mockSavedCalculations = [
  {
    id: '1',
    name: 'Home Solar System',
    date: '2025-05-01',
    systemSize: 8.4,
    location: 'San Francisco, CA',
    dailyConsumption: 24
  },
  {
    id: '2',
    name: 'Vacation Home',
    date: '2025-04-28',
    systemSize: 5.6,
    location: 'Los Angeles, CA',
    dailyConsumption: 18
  }
];

const SavedCalculationsList: React.FC = () => {
  const { user } = useAuth();
  const [savedCalculations, setSavedCalculations] = useState(mockSavedCalculations);
  
  const handleDeleteCalculation = (id: string) => {
    setSavedCalculations(savedCalculations.filter(calc => calc.id !== id));
    toast.success('Calculation deleted');
  };
  
  const handleLoadCalculation = (id: string) => {
    toast.success('Calculation loaded');
    // In a real app, this would load the calculation data
  };
  
  const handleSaveCurrentCalculation = () => {
    // In a real app, this would save the current calculation
    toast.success('Current calculation saved');
    
    // Mock adding a new calculation
    const newCalc = {
      id: Date.now().toString(),
      name: `New Calculation ${savedCalculations.length + 1}`,
      date: new Date().toISOString().split('T')[0],
      systemSize: 7.2,
      location: 'Sacramento, CA',
      dailyConsumption: 22
    };
    
    setSavedCalculations([...savedCalculations, newCalc]);
  };

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium">Saved Calculations</h3>
          <Button 
            size="sm" 
            className="flex items-center gap-1"
            onClick={handleSaveCurrentCalculation}
          >
            <Save className="h-4 w-4" />
            Save
          </Button>
        </div>
        
        {savedCalculations.length > 0 ? (
          <div className="space-y-3">
            {savedCalculations.map((calculation) => (
              <div 
                key={calculation.id} 
                className="p-3 rounded-md border border-border flex justify-between items-center hover:bg-accent/50 transition-colors"
              >
                <div className="space-y-1">
                  <h4 className="font-medium">{calculation.name}</h4>
                  <div className="text-xs text-muted-foreground">
                    {calculation.location} • {calculation.systemSize} kW • {calculation.date}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8"
                    onClick={() => handleLoadCalculation(calculation.id)}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-destructive"
                    onClick={() => handleDeleteCalculation(calculation.id)}
                  >
                    <Trash className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-4">
            <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center mx-auto mb-3">
              <Calculator className="h-6 w-6 text-muted-foreground" />
            </div>
            <p className="text-sm text-muted-foreground mb-4">
              No saved calculations yet
            </p>
            <Button 
              variant="outline" 
              size="sm" 
              className="flex items-center gap-1"
              onClick={handleSaveCurrentCalculation}
            >
              <Plus className="h-4 w-4" />
              Save Current Calculation
            </Button>
          </div>
        )}

        {user?.subscriptionTier === 'basic' && savedCalculations.length >= 10 && (
          <div className="mt-3 text-xs text-muted-foreground">
            <p>You've reached the limit of 10 saved calculations for your Basic plan.</p>
            <a href="/pricing" className="text-primary hover:underline">Upgrade to Professional for unlimited calculations</a>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SavedCalculationsList;
