
import React from 'react';
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Building, Waves, DollarSign } from 'lucide-react';

interface PremiumFeaturesProps {
  multiZone: boolean;
  setMultiZone: React.Dispatch<React.SetStateAction<boolean>>;
  customUtilityRates: boolean;
  setCustomUtilityRates: React.Dispatch<React.SetStateAction<boolean>>;
}

const PremiumFeatures: React.FC<PremiumFeaturesProps> = ({
  multiZone,
  setMultiZone,
  customUtilityRates,
  setCustomUtilityRates
}) => {
  return (
    <div className="space-y-4 border-t border-zinc-100 pt-4 mt-4">
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <h3 className="font-medium text-lg flex items-center gap-2">
            <span className="text-sm px-2 py-0.5 bg-primary/10 text-primary rounded-full">Pro</span>
            Advanced Features
          </h3>
          <p className="text-sm text-muted-foreground">Professional-only calculation options</p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between py-2">
          <div>
            <div className="flex items-center gap-2">
              <Building className="h-4 w-4 text-zinc-500" />
              <Label htmlFor="multiZone" className="input-label">Multi-Zone Calculation</Label>
            </div>
            <div className="text-sm text-zinc-500">Calculate for multiple roof areas</div>
          </div>
          <Switch
            id="multiZone"
            checked={multiZone}
            onCheckedChange={setMultiZone}
          />
        </div>
        
        {multiZone && (
          <div className="pl-4 border-l-2 border-primary/30">
            <p className="text-sm text-muted-foreground mb-2">
              Define multiple roof zones with different parameters
            </p>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="zone1" className="text-xs">Zone 1 Area (m²)</Label>
                <Input id="zone1" placeholder="50" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="zone1Angle" className="text-xs">Zone 1 Angle (°)</Label>
                <Input id="zone1Angle" placeholder="30" className="mt-1" />
              </div>
            </div>
            <button className="text-xs text-primary mt-2">+ Add another zone</button>
          </div>
        )}
        
        <div className="flex items-center justify-between py-2">
          <div>
            <div className="flex items-center gap-2">
              <DollarSign className="h-4 w-4 text-zinc-500" />
              <Label htmlFor="customUtilityRates" className="input-label">Custom Utility Rates</Label>
            </div>
            <div className="text-sm text-zinc-500">Add time-of-use rates and tiers</div>
          </div>
          <Switch
            id="customUtilityRates"
            checked={customUtilityRates}
            onCheckedChange={setCustomUtilityRates}
          />
        </div>
        
        {customUtilityRates && (
          <div className="pl-4 border-l-2 border-primary/30">
            <p className="text-sm text-muted-foreground mb-2">
              Enter your custom electricity rates
            </p>
            <div className="space-y-2">
              <div>
                <Label htmlFor="baseRate" className="text-xs">Base Rate ($/kWh)</Label>
                <Input id="baseRate" placeholder="0.25" className="mt-1" />
              </div>
              <div>
                <Label htmlFor="peakRate" className="text-xs">Peak Rate ($/kWh)</Label>
                <Input id="peakRate" placeholder="0.45" className="mt-1" />
              </div>
            </div>
          </div>
        )}
        
        <div className="flex items-center justify-between py-2">
          <div>
            <div className="flex items-center gap-2">
              <Waves className="h-4 w-4 text-zinc-500" />
              <Label htmlFor="advancedShading" className="input-label">Advanced Shading Analysis</Label>
            </div>
            <div className="text-sm text-zinc-500">Detailed shade modeling by time of day</div>
          </div>
          <Switch
            id="advancedShading"
            checked={false}
            onCheckedChange={() => {}}
          />
        </div>
      </div>
    </div>
  );
};

export default PremiumFeatures;
