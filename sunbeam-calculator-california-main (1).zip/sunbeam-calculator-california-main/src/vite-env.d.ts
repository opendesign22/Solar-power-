
/// <reference types="vite/client" />

// Extend Window interface to include adsbygoogle
interface Window {
  adsbygoogle?: any[];
}
